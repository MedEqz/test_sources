# Etapes pour l'excercie 3

* chmod 775 start.sh
* executez start.sh pour monter le docker contenant un serveur express
* npx tsc à l'intérieur du conteneur pour recompiler le fichier arrow.ts en arrow.js (si nécessaire)

## Remarque

Sauf erreur de ma part, l'exercice 3 demande d'utiliser la fonction créé lors de l'exercice 2, or la fonction en question reçoit en input un fichier .txt
Pour l'exercice 3 j'ai donc repris la fonction de l'exercice 1 qui elle prend bien en input un chaine de caratères string, comme demandé dans l'exercice 3
